// VNO atvykimai — Cloudflare Worker (duomenų tarpininkas)
// Берёт расписание прилётов VNO из Flightradar24 и живые позиции самолётов
// из открытых ADS-B сетей (adsb.lol / airplanes.live), отдаёт приложению одним JSON.
// Деплой: Cloudflare → Workers & Pages → Create → Worker → вставить этот код → Deploy.

const VNO = { lat: 54.6341, lon: 25.2858 };
const RADIUS_NM = 150; // ~280 km вокруг аэропорта
const CACHE_SECONDS = 20;

const BROWSER_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
  Accept: "application/json, text/plain, */*",
  "Accept-Language": "en-US,en;q=0.9",
  Origin: "https://www.flightradar24.com",
  Referer: "https://www.flightradar24.com/",
};

function cors(h = new Headers()) {
  h.set("Access-Control-Allow-Origin", "*");
  h.set("Access-Control-Allow-Methods", "GET, OPTIONS");
  h.set("Access-Control-Allow-Headers", "*");
  return h;
}

async function getJSON(url, headers = {}) {
  const r = await fetch(url, { headers, cf: { cacheTtl: 15 } });
  if (!r.ok) throw new Error(`${new URL(url).hostname} HTTP ${r.status}`);
  return r.json();
}

// ---------- Flightradar24: расписание прилётов ----------
function fr24Url(page) {
  const ts = Math.floor(Date.now() / 1000);
  return (
    "https://api.flightradar24.com/common/v1/airport.json?code=vno" +
    "&plugin[]=schedule&plugin-setting[schedule][mode]=arrivals" +
    `&plugin-setting[schedule][timestamp]=${ts}&page=${page}&limit=100`
  );
}

function normFR(item) {
  const f = item.flight || {};
  const id = f.identification || {};
  const t = f.time || {};
  const o = (f.airport && f.airport.origin) || {};
  const pos = o.position || {};
  return {
    id: id.id || `${id.number && id.number.default}-${t.scheduled && t.scheduled.arrival}`,
    flight: (id.number && id.number.default) || id.callsign || "",
    callsign: id.callsign || "",
    airline: (f.airline && f.airline.name) || "",
    aircraft: (f.aircraft && f.aircraft.model && f.aircraft.model.code) || "",
    aircraftName: (f.aircraft && f.aircraft.model && f.aircraft.model.text) || "",
    reg: (f.aircraft && f.aircraft.registration) || "",
    fromCity: (pos.region && pos.region.city) || "",
    fromName: o.name || "",
    fromCode: (o.code && o.code.iata) || "",
    fromCountry: (pos.country && pos.country.name) || "",
    sched: (t.scheduled && t.scheduled.arrival) || null,
    est: (t.estimated && t.estimated.arrival) || (t.other && t.other.eta) || null,
    real: (t.real && t.real.arrival) || null,
    status: (f.status && f.status.generic && f.status.generic.status && f.status.generic.status.text) || "",
    statusText: (f.status && f.status.text) || "",
    airborne: !!(f.status && f.status.live),
  };
}

async function getSchedule() {
  const pages = await Promise.allSettled([
    getJSON(fr24Url(-1), BROWSER_HEADERS),
    getJSON(fr24Url(1), BROWSER_HEADERS),
  ]);
  const map = new Map();
  let ok = false;
  for (const p of pages) {
    if (p.status !== "fulfilled") continue;
    const data =
      p.value?.result?.response?.airport?.pluginData?.schedule?.arrivals?.data || [];
    ok = true;
    for (const item of data) {
      const n = normFR(item);
      if (n.sched) map.set(n.id, n);
    }
  }
  if (!ok) throw new Error("Flightradar24 nepasiekiamas");
  return [...map.values()].sort((a, b) => a.sched - b.sched);
}

// ---------- ADS-B: самолёты в воздухе рядом с Вильнюсом ----------
async function getLive() {
  const sources = [
    `https://api.adsb.lol/v2/point/${VNO.lat}/${VNO.lon}/${RADIUS_NM}`,
    `https://api.adsb.lol/v2/lat/${VNO.lat}/lon/${VNO.lon}/dist/${RADIUS_NM}`,
    `https://api.airplanes.live/v2/point/${VNO.lat}/${VNO.lon}/${RADIUS_NM}`,
  ];
  for (const url of sources) {
    try {
      const j = await getJSON(url, { "User-Agent": "VNO-arrivals-pwa/1.0" });
      const ac = j.ac || j.aircraft || [];
      return ac
        .filter((a) => a.lat != null && a.lon != null)
        .map((a) => ({
          callsign: (a.flight || "").trim(),
          reg: a.r || "",
          type: a.t || "",
          lat: a.lat,
          lon: a.lon,
          ground: a.alt_baro === "ground",
          alt: a.alt_baro === "ground" ? 0 : a.alt_baro ?? a.alt_geom ?? null,
          gs: a.gs ?? null,
          vr: a.baro_rate ?? a.geom_rate ?? null,
          track: a.track ?? null,
        }));
    } catch (e) {
      /* пробуем следующий источник */
    }
  }
  throw new Error("ADS-B nepasiekiamas");
}

export default {
  async fetch(req, env, ctx) {
    if (req.method === "OPTIONS") return new Response(null, { headers: cors() });
    const url = new URL(req.url);
    if (url.pathname !== "/arrivals") {
      return new Response("VNO atvykimų API veikia. Naudokite /arrivals", {
        headers: cors(new Headers({ "content-type": "text/plain; charset=utf-8" })),
      });
    }

    const cache = caches.default;
    const key = new Request("https://vno-cache.internal/arrivals");
    const hit = await cache.match(key);
    if (hit) return new Response(hit.body, { headers: cors(new Headers(hit.headers)) });

    const [sched, live] = await Promise.allSettled([getSchedule(), getLive()]);
    const errors = [];
    if (sched.status === "rejected") errors.push(String(sched.reason.message || sched.reason));
    if (live.status === "rejected") errors.push(String(live.reason.message || live.reason));

    const body = JSON.stringify({
      updated: Date.now(),
      source: "Flightradar24 + ADS-B",
      flights: sched.status === "fulfilled" ? sched.value : [],
      live: live.status === "fulfilled" ? live.value : [],
      errors,
    });
    const headers = new Headers({
      "content-type": "application/json; charset=utf-8",
      "cache-control": `public, max-age=${CACHE_SECONDS}`,
    });
    const res = new Response(body, { headers });
    if (sched.status === "fulfilled") ctx.waitUntil(cache.put(key, res.clone()));
    return new Response(body, { headers: cors(new Headers(headers)) });
  },
};
